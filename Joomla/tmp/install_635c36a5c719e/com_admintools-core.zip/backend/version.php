<?php
/**
 * @package   admintools
 * @copyright Copyright (c)2010-2020 Nicholas K. Dionysopoulos / Akeeba Ltd
 * @license   GNU General Public License version 3, or later
 */

// Protect from unauthorized access
defined('_JEXEC') or die;

define('ADMINTOOLS_VERSION', '5.6.0');
define('ADMINTOOLS_DATE', '2020-03-20');
define('ADMINTOOLS_PRO','0');